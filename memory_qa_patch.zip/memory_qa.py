
# memory_qa.py
from __future__ import annotations

import time
import re
from dataclasses import dataclass
from typing import List, Tuple, Optional

import numpy as np

from graph_mem import GraphMem, Fact

FAQ_A_RE = re.compile(r"^\s*A:\s*(?P<a>.+)$", re.IGNORECASE | re.MULTILINE)
FAQ_Q_RE = re.compile(r"^\s*Q:\s*(?P<q>.+)$", re.IGNORECASE | re.MULTILINE)
FAQ_CAT_RE = re.compile(r"^\s*\[CATEGORY\]\s*(?P<c>.+)$", re.IGNORECASE | re.MULTILINE)

def _cosine(a: np.ndarray, b: np.ndarray) -> float:
    da, db = float(np.linalg.norm(a)), float(np.linalg.norm(b))
    if da == 0.0 or db == 0.0: return 0.0
    return float(np.dot(a, b) / (da * db))

def _recency(now_ts: float, ts: float) -> float:
    days = max(0.0, (now_ts - ts) / 86400.0)
    return 1.0 / (1.0 + days)

@dataclass
class AnswerCandidate:
    fact: Fact
    sim: float
    rec: float
    score: float
    answer_text: str
    question_text: str
    category: Optional[str]

class MemoryQABot:
    def __init__(self, gm: GraphMem, alpha: float = 0.7, min_sim: float = 0.35):
        self.gm = gm
        self.alpha = alpha
        self.min_sim = min_sim

    def _extract_a(self, text: str) -> str:
        m = FAQ_A_RE.search(text)
        return m.group("a").strip() if m else text.strip()

    def _extract_q(self, text: str) -> str:
        m = FAQ_Q_RE.search(text)
        return m.group("q").strip() if m else ""

    def _extract_cat(self, text: str) -> Optional[str]:
        m = FAQ_CAT_RE.search(text)
        return m.group("c").strip() if m else None

    def retrieve(self, query: str, now_ts: Optional[float] = None, k: int = 5) -> List[AnswerCandidate]:
        now_ts = now_ts or time.time()
        # Use GraphMem's retrieval to shortlist
        cands = self.gm.retrieve(query, now_ts=now_ts, k=k)
        qv = self.gm.embed(query)
        out: List[AnswerCandidate] = []
        for f in cands:
            sim = _cosine(qv, f.vec)
            rec = _recency(now_ts, f.ts)
            score = self.alpha * sim + (1.0 - self.alpha) * rec
            out.append(AnswerCandidate(
                fact=f,
                sim=sim, rec=rec, score=score,
                answer_text=self._extract_a(f.text),
                question_text=self._extract_q(f.text),
                category=self._extract_cat(f.text)
            ))
        out.sort(key=lambda x: -x.score)
        return out

    def answer(self, query: str, now_ts: Optional[float] = None, k: int = 5) -> dict:
        cands = self.retrieve(query, now_ts=now_ts, k=k)
        if not cands or cands[0].sim < self.min_sim:
            return {
                "answer": "Nie mam pewnej odpowiedzi w pamięci. Spróbuj doprecyzować pytanie lub użyj innego sformułowania.",
                "candidates": [{
                    "preview": c.fact.text.splitlines()[:2],
                    "score": round(c.score, 3),
                    "sim": round(c.sim, 3),
                    "recency": round(c.rec, 3),
                    "category": c.category,
                    "question": c.question_text
                } for c in cands]
            }
        best = cands[0]
        return {
            "answer": best.answer_text,
            "category": best.category,
            "matched_question": best.question_text,
            "score": round(best.score, 3),
            "sim": round(best.sim, 3),
            "recency": round(best.rec, 3),
            "alternatives": [{
                "answer": c.answer_text,
                "category": c.category,
                "question": c.question_text,
                "score": round(c.score, 3)
            } for c in cands[1:3]]
        }

# Convenience factory
def build_bot_from_faq(faq_path: str, alpha: float = 0.7, min_sim: float = 0.35) -> MemoryQABot:
    from adapters.faq_ingest_adapter import ingest_faq_to_graph
    gm = GraphMem()
    ingest_faq_to_graph(faq_path, gm)
    return MemoryQABot(gm, alpha=alpha, min_sim=min_sim)

if __name__ == "__main__":
    import argparse, json
    ap = argparse.ArgumentParser()
    ap.add_argument("--faq", default="data/banking_faq_30plus.txt")
    ap.add_argument("--q", help="Pytanie użytkownika", required=True)
    ap.add_argument("--alpha", type=float, default=0.7)
    ap.add_argument("--min-sim", type=float, default=0.35)
    args = ap.parse_args()

    bot = build_bot_from_faq(args.faq, alpha=args.alpha, min_sim=args.min_sim)
    out = bot.answer(args.q)
    print(json.dumps(out, ensure_ascii=False, indent=2))
